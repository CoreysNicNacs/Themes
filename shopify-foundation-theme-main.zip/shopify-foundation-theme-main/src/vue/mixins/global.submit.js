export default {
  methods: {
    submit (event) {
      event.target.form.submit()
    }
  }
}