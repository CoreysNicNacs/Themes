<!-- logo (start) -->
<p align="center">
  <img src="https://raw.githubusercontent.com/uicrooks/shopify-foundation-theme/master/.github/img/logo.svg" width="325px">
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/uicrooks/shopify-foundation-theme/master/.github/img/banner.svg" width="400px">
</p>
<!-- logo (end) -->

<!-- badges (start) -->
<p align="center">
  <img src="https://img.shields.io/github/package-json/v/uicrooks/shopify-foundation-theme?color=%236e78ff">
  <img src="https://img.shields.io/github/package-json/dependency-version/uicrooks/shopify-foundation-theme/vue?color=%234fc08d">
  <img src="https://img.shields.io/github/package-json/dependency-version/uicrooks/shopify-foundation-theme/tailwindcss?color=%2306b6d4">
</p>
<!-- badges (end) -->

<!-- title / description (start) -->
<h2 align="center">Shopify Foundation Theme</h2>

Shopify Foundation Theme is modern Shopify theme built with [Shopify Theme Lab](https://github.com/uicrooks/shopify-theme-lab), [Vue](https://v3.vuejs.org/) and [Tailwind CSS](https://tailwindcss.com).

> If you are looking for the old Foundation Theme it's here: [Legacy Version 3 branch](https://github.com/uicrooks/shopify-foundation-theme/tree/legacy-v3)
<!-- title / description (end) -->

<!-- preview (start) -->
<img src="https://raw.githubusercontent.com/uicrooks/shopify-foundation-theme/master/.github/img/preview.png" width="100%">
<!-- preview (end) -->

<!-- features (start) -->
## Features

- All [Shopify Theme Lab](https://github.com/uicrooks/shopify-theme-lab#features) features
- Online Store 2.0 support
- Starter Theme ready for customization
- Clean structure
- Vue.js
- Tailwind CSS
- Responsive
- Image lazy-loading
<!-- features (end) -->

<!-- docs (start) -->
## Docs

Everything from the [Shopify Theme Lab docs](https://uicrooks.github.io/shopify-theme-lab-docs) applies to this project, since it was built with Shopify Theme Lab.
<!-- docs (end) -->