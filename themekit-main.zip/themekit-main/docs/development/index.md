---
title: Developing Theme Kit
redirect_to: https://github.com/Shopify/themekit/blob/main/CONTRIBUTING.md
---
