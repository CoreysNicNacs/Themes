---
title: Configuration reference
redirect_to: https://shopify.dev/tools/theme-kit/configuration-reference
---
